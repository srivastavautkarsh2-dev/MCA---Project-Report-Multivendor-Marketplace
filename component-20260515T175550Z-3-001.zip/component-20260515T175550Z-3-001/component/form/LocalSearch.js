import React from "react";

const LocalSearch = ({ keyword, setkeyword }) => {
   
   
    const handleSearchChange = (e) => {
        e.preventDefault()
        setkeyword(e.target.value.toLowerCase())
    }
    return (
        <div className="container pt-4 pb-4">
            <input type="search"
                placeholder="filter"
                value={keyword}
                onChange={handleSearchChange}
                className="form-control mb-4"
            />

        </div>

    )
}
export default LocalSearch;