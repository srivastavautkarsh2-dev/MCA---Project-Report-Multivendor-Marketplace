import React from "react";
import Resizer from 'react-image-file-resizer';
import axios from "axios";
import {useSelector} from  "react-redux"
import {Avatar ,Badge,} from "antd";
const FileUplaod=({values,setvalues,setloading})=>
{
const {user}=useSelector((state)=>({...state}))
    const fileUploadAndResize=(e)=>
    {
      //  console.log(e.target.files)

 let files=e.target.files;
 let allUploadedFiles=values.images;
if(files)
{
    setloading(true);
    for(let i=0;i<files.length;i++)
     {
       Resizer.imageFileResizer(files[i],720,720,'JPEG',100,0,
        (uri) =>
         {
        // console.log(uri);
        //  console.log(allUploadedFiles)
           axios.post(`http://localhost:8081/api/uploadimages`,{image:uri}, 
           {headers:
             {authtoken:user ? user.token:""
            }
        }
        )
           .then(res =>
             {
                 console.log("images upload res url",res)
                 console.log(allUploadedFiles)
                 console.log(user)
 setloading(false);
 allUploadedFiles.push(res.data)
 setvalues({...values ,images:allUploadedFiles});
console.log(allUploadedFiles)
             }).catch(err=>
                 {
                     setloading(false);
                    console.log("cloudinary err",err)
                 })
        },        "base64"
         )
    }

 }
    };
    const handleImageRemove=(public_id)=>
    {
setloading(true)
console.log("remove image",public_id )
axios.post(`http://localhost:8081/api/removeimage`,{public_id},
{
    headers:{
        authtoken:user ? user.token:"",
    }
}).then(res=>
    {
        setloading(false)
        const{images}=values
        let filteredImages=images.filter((item)=>{
            return item.public_id!==public_id;
        })
        setvalues({...values,images:filteredImages})
    })
.catch(err=>
    {
        console.log(err)
        setloading(false)
    })
    }
    return(
        <>
         <div className="row">
             {values.images && values.images.map((image)=>
            (
               <Badge count="x" key={image.public_id}
                onClick={()=>handleImageRemove(image.public_id)}
                style={{cursor:"pointer"}}>
 <Avatar  src={image.url} size={100}
                className="ml-3"
                shape="square"/>
               </Badge>
            ) )}
         </div>
        
    <div className="row">
        <label className="btn btn-primary btn-raised mt-3">
            choose File
        

        <input
        type="file"
        multiple hidden accept="images/*"
        onChange={fileUploadAndResize} />
</label>

    </div>
    </>
    )
} 

export default FileUplaod;